/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui.config;

/**
 *
 * @author Oussama EZZIOURI
 */
public class ConfigMsg{
    
    /**
     * Load database configuration file %s ...
     */
    public static String[] APP_CONFIG0001 = {"APP_CONFIG0001", "APP_CONFIG0001 : Load database configuration file %s ..."};
    /**
     * Loading DATAMATRIX_PATTERN_LIST pattern list ...
     */
    public static String[] APP_CONFIG0002 = {"APP_CONFIG0002", "APP_CONFIG0002 : Loading DATAMATRIX_PATTERN_LIST pattern list ..."};
    /**
     *  %s QR Code pattern for project %s successfully loaded 100% !
     */
    public static String[] APP_CONFIG0003 = {"APP_CONFIG0003", "APP_CONFIG0003 : %s QR Code pattern for project %s successfully loaded."};
    /**
     *  %s part number patterns for project %s successfully loaded 100% !
     */
    public static String[] APP_CONFIG0004 = {"APP_CONFIG0004", "APP_CONFIG0004 : %s part number patterns for project %s successfully loaded."};

    
    
}

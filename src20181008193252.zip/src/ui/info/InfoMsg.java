/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui.info;

/**
 *
 * @author Oussama EZZIOURI
 */
public class InfoMsg {

    /**
     * Are you sure you want to exit the program ?
     */
    public static String[] APP_INFO0001 = {"APP_INFO0001", "APP_INFO0001 : Are you sure you want to exit the program ?", "", ""};
    /**
     * Load database configuration file %s ...
     */
    public static String[] APP_INFO0002 = {"APP_INFO0002", "APP_INFO0002 : Load database configuration file %s ..."};

    /**
     * User %s connected to host %s at %s.
     */
    public static String[] APP_INFO0003 = {"APP_INFO0003", "APP_INFO0003 : User %s connected to host %s at %s."};

    /**
     * Harness part %s found for project [%s].
     */
    public static String[] APP_INFO0004 = {"APP_INFO0004", "APP_INFO0004 : Part number %s found for project [%s]."};

    /**
     * Correct part number %s 
     *
     */
    public static String[] APP_INFO0005 = {"APP_INFO0005", "APP_INFO0005 : Correct part number %s "};

    /**
     *
     */
    public static String[] APP_INFO0006 = {"APP_INFO0006", ""};

    /**
     *
     */
    public static String[] APP_INFO0007 = {"APP_INFO0007", ""};

    /**
     *
     */
    public static String[] APP_INFO0008 = {"APP_INFO0008", ""};

    /**
     *
     */
    public static String[] APP_INFO0009 = {"APP_INFO0009", ""};

    /**
     *
     */
    public static String[] APP_INFO0010 = {"APP_INFO0010", ""};

    /**
     *
     */
    public static String[] APP_INFO0011 = {"APP_INFO0011", ""};

    /**
     *
     */
    public static String[] APP_INFO0012 = {"APP_INFO0012", ""};

    /**
     *
     */
    public static String[] APP_INFO0013 = {"APP_INFO0013", ""};

    /**
     *
     */
    public static String[] APP_INFO0014 = {"APP_INFO0014", ""};

    /**
     *
     */
    public static String[] APP_INFO0015 = {"APP_INFO0015", ""};

    /**
     *
     */
    public static String[] APP_INFO0016 = {"APP_INFO0016", ""};

    /**
     *
     */
    public static String[] APP_INFO0017 = {"APP_INFO0017", ""};

    /**
     *
     */
    public static String[] APP_INFO0018 = {"APP_INFO0018", ""};

    /**
     *
     */
    public static String[] APP_INFO0019 = {"APP_INFO0019", ""};

    /**
     *
     */
    public static String[] APP_INFO0020 = {"APP_INFO0020", ""};

    /**
     *
     */
    public static String[] APP_INFO0021 = {"APP_INFO0021", ""};

    /**
     *
     */
    public static String[] APP_INFO0022 = {"APP_INFO0022", ""};

    /**
     *
     */
    public static String[] APP_INFO0023 = {"APP_INFO0023", ""};

    /**
     *
     */
    public static String[] APP_INFO0024 = {"APP_INFO0024", ""};

    /**
     *
     */
    public static String[] APP_INFO0025 = {"APP_INFO0025", ""};

    /**
     *
     */
    public static String[] APP_INFO0026 = {"APP_INFO0026", ""};

    /**
     *
     */
    public static String[] APP_INFO0027 = {"APP_INFO0027", ""};

    /**
     *
     */
    public static String[] APP_INFO0028 = {"APP_INFO0028", ""};

    /**
     *
     */
    public static String[] APP_INFO0029 = {"APP_INFO0029", ""};

    /**
     *
     */
    public static String[] APP_INFO0030 = {"APP_INFO0030", ""};

    /**
     *
     */
    public static String[] APP_INFO0031 = {"APP_INFO0031", ""};

    /**
     *
     */
    public static String[] APP_INFO0032 = {"APP_INFO0032", ""};

    /**
     *
     */
    public static String[] APP_INFO0033 = {"APP_INFO0033", ""};

    /**
     *
     */
    public static String[] APP_INFO0034 = {"APP_INFO0034", ""};

    /**
     *
     */
    public static String[] APP_INFO0035 = {"APP_INFO0035", ""};

    /**
     *
     */
    public static String[] APP_INFO0036 = {"APP_INFO0036", ""};

    /**
     *
     */
    public static String[] APP_INFO0037 = {"APP_INFO0037", ""};

    /**
     *
     */
    public static String[] APP_INFO0038 = {"APP_INFO0038", ""};

    /**
     *
     */
    public static String[] APP_INFO0039 = {"APP_INFO0039", ""};

    /**
     *
     */
    public static String[] APP_INFO0040 = {"APP_INFO0040", ""};

    /**
     *
     */
    public static String[] APP_INFO0041 = {"APP_INFO0041", ""};

    /**
     *
     */
    public static String[] APP_INFO0042 = {"APP_INFO0042", ""};

    /**
     *
     */
    public static String[] APP_INFO0043 = {"APP_INFO0043", ""};

    /**
     *
     */
    public static String[] APP_INFO0044 = {"APP_INFO0044", ""};

    /**
     *
     */
    public static String[] APP_INFO0045 = {"APP_INFO0045", ""};

    /**
     *
     */
    public static String[] APP_INFO0046 = {"APP_INFO0046", ""};

    /**
     *
     */
    public static String[] APP_INFO0047 = {"APP_INFO0047", ""};

    /**
     *
     */
    public static String[] APP_INFO0048 = {"APP_INFO0048", ""};

    /**
     *
     */
    public static String[] APP_INFO0049 = {"APP_INFO0049", ""};

    /**
     *
     */
    public static String[] APP_INFO0050 = {"APP_INFO0050", ""};

    /**
     *
     */
    public static String[] APP_INFO0051 = {"APP_INFO0051", ""};

    /**
     *
     */
    public static String[] APP_INFO0052 = {"APP_INFO0052", ""};

    /**
     *
     */
    public static String[] APP_INFO0053 = {"APP_INFO0053", ""};

    /**
     *
     */
    public static String[] APP_INFO0054 = {"APP_INFO0054", ""};

    /**
     *
     */
    public static String[] APP_INFO0055 = {"APP_INFO0055", ""};

    /**
     *
     */
    public static String[] APP_INFO0056 = {"APP_INFO0056", ""};

    /**
     *
     */
    public static String[] APP_INFO0057 = {"APP_INFO0057", ""};

    /**
     *
     */
    public static String[] APP_INFO0058 = {"APP_INFO0058", ""};

    /**
     *
     */
    public static String[] APP_INFO0059 = {"APP_INFO0059", ""};

    /**
     *
     */
    public static String[] APP_INFO0060 = {"APP_INFO0060", ""};

    /**
     *
     */
    public static String[] APP_INFO0061 = {"APP_INFO0061", ""};

    /**
     *
     */
    public static String[] APP_INFO0062 = {"APP_INFO0062", ""};

    /**
     *
     */
    public static String[] APP_INFO0063 = {"APP_INFO0063", ""};

    /**
     *
     */
    public static String[] APP_INFO0064 = {"APP_INFO0064", ""};

    /**
     *
     */
    public static String[] APP_INFO0065 = {"APP_INFO0065", ""};

    /**
     *
     */
    public static String[] APP_INFO0066 = {"APP_INFO0066", ""};

    /**
     *
     */
    public static String[] APP_INFO0067 = {"APP_INFO0067", ""};

    /**
     *
     */
    public static String[] APP_INFO0068 = {"APP_INFO0068", ""};

    /**
     *
     */
    public static String[] APP_INFO0069 = {"APP_INFO0069", ""};

    /**
     *
     */
    public static String[] APP_INFO0070 = {"APP_INFO0070", ""};

    /**
     *
     */
    public static String[] APP_INFO0071 = {"APP_INFO0071", ""};

    /**
     *
     */
    public static String[] APP_INFO0072 = {"APP_INFO0072", ""};

    /**
     *
     */
    public static String[] APP_INFO0073 = {"APP_INFO0073", ""};

    /**
     *
     */
    public static String[] APP_INFO0074 = {"APP_INFO0074", ""};

    /**
     *
     */
    public static String[] APP_INFO0075 = {"APP_INFO0075", ""};

    /**
     *
     */
    public static String[] APP_INFO0076 = {"APP_INFO0076", ""};

    /**
     *
     */
    public static String[] APP_INFO0077 = {"APP_INFO0077", ""};

    /**
     *
     */
    public static String[] APP_INFO0078 = {"APP_INFO0078", ""};

    /**
     *
     */
    public static String[] APP_INFO0079 = {"APP_INFO0079", ""};

    /**
     *
     */
    public static String[] APP_INFO0080 = {"APP_INFO0080", ""};

    /**
     *
     */
    public static String[] APP_INFO0081 = {"APP_INFO0081", ""};

    /**
     *
     */
    public static String[] APP_INFO0082 = {"APP_INFO0082", ""};

    /**
     *
     */
    public static String[] APP_INFO0083 = {"APP_INFO0083", ""};

    /**
     *
     */
    public static String[] APP_INFO0084 = {"APP_INFO0084", ""};

    /**
     *
     */
    public static String[] APP_INFO0085 = {"APP_INFO0085", ""};

    /**
     *
     */
    public static String[] APP_INFO0086 = {"APP_INFO0086", ""};

    /**
     *
     */
    public static String[] APP_INFO0087 = {"APP_INFO0087", ""};

    /**
     *
     */
    public static String[] APP_INFO0088 = {"APP_INFO0088", ""};

    /**
     *
     */
    public static String[] APP_INFO0089 = {"APP_INFO0089", ""};

    /**
     *
     */
    public static String[] APP_INFO0090 = {"APP_INFO0090", ""};

    /**
     *
     */
    public static String[] APP_INFO0091 = {"APP_INFO0091", ""};

    /**
     *
     */
    public static String[] APP_INFO0092 = {"APP_INFO0092", ""};

    /**
     *
     */
    public static String[] APP_INFO0093 = {"APP_INFO0093", ""};

    /**
     *
     */
    public static String[] APP_INFO0094 = {"APP_INFO0094", ""};

    /**
     *
     */
    public static String[] APP_INFO0095 = {"APP_INFO0095", ""};

    /**
     *
     */
    public static String[] APP_INFO0096 = {"APP_INFO0096", ""};

    /**
     *
     */
    public static String[] APP_INFO0097 = {"APP_INFO0097", ""};

    /**
     *
     */
    public static String[] APP_INFO0098 = {"APP_INFO0098", ""};

    /**
     *
     */
    public static String[] APP_INFO0099 = {"APP_INFO0099", ""};

    /**
     *
     */
    public static String[] APP_INFO0100 = {"APP_INFO0100", ""};

}

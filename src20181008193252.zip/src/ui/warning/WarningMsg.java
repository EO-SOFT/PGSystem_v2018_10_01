/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui.warning;

/**
 *
 * @author Oussama EZZIOURI
 */
public class WarningMsg {

    /**
     *
     */
    public static String[] APP_WARN0001 = {"APP_WARN0001", ""};

    /**
     *
     */
    public static String[] APP_WARN0002 = {"APP_WARN0002", ""};

    /**
     *
     */
    public static String[] APP_WARN0003 = {"APP_WARN0003", ""};

    /**
     *
     */
    public static String[] APP_WARN0004 = {"APP_WARN0004", ""};

    /**
     *
     */
    public static String[] APP_WARN0005 = {"APP_WARN0005", ""};

    /**
     *
     */
    public static String[] APP_WARN0006 = {"APP_WARN0006", ""};

    /**
     *
     */
    public static String[] APP_WARN0007 = {"APP_WARN0007", ""};

    /**
     *
     */
    public static String[] APP_WARN0008 = {"APP_WARN0008", ""};

    /**
     *
     */
    public static String[] APP_WARN0009 = {"APP_WARN0009", ""};

    /**
     *
     */
    public static String[] APP_WARN0010 = {"APP_WARN0010", ""};

    /**
     *
     */
    public static String[] APP_WARN0011 = {"APP_WARN0011", ""};

    /**
     *
     */
    public static String[] APP_WARN0012 = {"APP_WARN0012", ""};

    /**
     *
     */
    public static String[] APP_WARN0013 = {"APP_WARN0013", ""};

    /**
     *
     */
    public static String[] APP_WARN0014 = {"APP_WARN0014", ""};

    /**
     *
     */
    public static String[] APP_WARN0015 = {"APP_WARN0015", ""};

    /**
     *
     */
    public static String[] APP_WARN0016 = {"APP_WARN0016", ""};

    /**
     *
     */
    public static String[] APP_WARN0017 = {"APP_WARN0017", ""};

    /**
     *
     */
    public static String[] APP_WARN0018 = {"APP_WARN0018", ""};

    /**
     *
     */
    public static String[] APP_WARN0019 = {"APP_WARN0019", ""};

    /**
     *
     */
    public static String[] APP_WARN0020 = {"APP_WARN0020", ""};

    /**
     *
     */
    public static String[] APP_WARN0021 = {"APP_WARN0021", ""};

    /**
     *
     */
    public static String[] APP_WARN0022 = {"APP_WARN0022", ""};

    /**
     *
     */
    public static String[] APP_WARN0023 = {"APP_WARN0023", ""};

    /**
     *
     */
    public static String[] APP_WARN0024 = {"APP_WARN0024", ""};

    /**
     *
     */
    public static String[] APP_WARN0025 = {"APP_WARN0025", ""};

    /**
     *
     */
    public static String[] APP_WARN0026 = {"APP_WARN0026", ""};

    /**
     *
     */
    public static String[] APP_WARN0027 = {"APP_WARN0027", ""};

    /**
     *
     */
    public static String[] APP_WARN0028 = {"APP_WARN0028", ""};

    /**
     *
     */
    public static String[] APP_WARN0029 = {"APP_WARN0029", ""};

    /**
     *
     */
    public static String[] APP_WARN0030 = {"APP_WARN0030", ""};

    /**
     *
     */
    public static String[] APP_WARN0031 = {"APP_WARN0031", ""};

    /**
     *
     */
    public static String[] APP_WARN0032 = {"APP_WARN0032", ""};

    /**
     *
     */
    public static String[] APP_WARN0033 = {"APP_WARN0033", ""};

    /**
     *
     */
    public static String[] APP_WARN0034 = {"APP_WARN0034", ""};

    /**
     *
     */
    public static String[] APP_WARN0035 = {"APP_WARN0035", ""};

    /**
     *
     */
    public static String[] APP_WARN0036 = {"APP_WARN0036", ""};

    /**
     *
     */
    public static String[] APP_WARN0037 = {"APP_WARN0037", ""};

    /**
     *
     */
    public static String[] APP_WARN0038 = {"APP_WARN0038", ""};

    /**
     *
     */
    public static String[] APP_WARN0039 = {"APP_WARN0039", ""};

    /**
     *
     */
    public static String[] APP_WARN0040 = {"APP_WARN0040", ""};

    /**
     *
     */
    public static String[] APP_WARN0041 = {"APP_WARN0041", ""};

    /**
     *
     */
    public static String[] APP_WARN0042 = {"APP_WARN0042", ""};

    /**
     *
     */
    public static String[] APP_WARN0043 = {"APP_WARN0043", ""};

    /**
     *
     */
    public static String[] APP_WARN0044 = {"APP_WARN0044", ""};

    /**
     *
     */
    public static String[] APP_WARN0045 = {"APP_WARN0045", ""};

    /**
     *
     */
    public static String[] APP_WARN0046 = {"APP_WARN0046", ""};

    /**
     *
     */
    public static String[] APP_WARN0047 = {"APP_WARN0047", ""};

    /**
     *
     */
    public static String[] APP_WARN0048 = {"APP_WARN0048", ""};

    /**
     *
     */
    public static String[] APP_WARN0049 = {"APP_WARN0049", ""};

    /**
     *
     */
    public static String[] APP_WARN0050 = {"APP_WARN0050", ""};

    /**
     *
     */
    public static String[] APP_WARN0051 = {"APP_WARN0051", ""};

    /**
     *
     */
    public static String[] APP_WARN0052 = {"APP_WARN0052", ""};

    /**
     *
     */
    public static String[] APP_WARN0053 = {"APP_WARN0053", ""};

    /**
     *
     */
    public static String[] APP_WARN0054 = {"APP_WARN0054", ""};

    /**
     *
     */
    public static String[] APP_WARN0055 = {"APP_WARN0055", ""};

    /**
     *
     */
    public static String[] APP_WARN0056 = {"APP_WARN0056", ""};

    /**
     *
     */
    public static String[] APP_WARN0057 = {"APP_WARN0057", ""};

    /**
     *
     */
    public static String[] APP_WARN0058 = {"APP_WARN0058", ""};

    /**
     *
     */
    public static String[] APP_WARN0059 = {"APP_WARN0059", ""};

    /**
     *
     */
    public static String[] APP_WARN0060 = {"APP_WARN0060", ""};

    /**
     *
     */
    public static String[] APP_WARN0061 = {"APP_WARN0061", ""};

    /**
     *
     */
    public static String[] APP_WARN0062 = {"APP_WARN0062", ""};

    /**
     *
     */
    public static String[] APP_WARN0063 = {"APP_WARN0063", ""};

    /**
     *
     */
    public static String[] APP_WARN0064 = {"APP_WARN0064", ""};

    /**
     *
     */
    public static String[] APP_WARN0065 = {"APP_WARN0065", ""};

    /**
     *
     */
    public static String[] APP_WARN0066 = {"APP_WARN0066", ""};

    /**
     *
     */
    public static String[] APP_WARN0067 = {"APP_WARN0067", ""};

    /**
     *
     */
    public static String[] APP_WARN0068 = {"APP_WARN0068", ""};

    /**
     *
     */
    public static String[] APP_WARN0069 = {"APP_WARN0069", ""};

    /**
     *
     */
    public static String[] APP_WARN0070 = {"APP_WARN0070", ""};

    /**
     *
     */
    public static String[] APP_WARN0071 = {"APP_WARN0071", ""};

    /**
     *
     */
    public static String[] APP_WARN0072 = {"APP_WARN0072", ""};

    /**
     *
     */
    public static String[] APP_WARN0073 = {"APP_WARN0073", ""};

    /**
     *
     */
    public static String[] APP_WARN0074 = {"APP_WARN0074", ""};

    /**
     *
     */
    public static String[] APP_WARN0075 = {"APP_WARN0075", ""};

    /**
     *
     */
    public static String[] APP_WARN0076 = {"APP_WARN0076", ""};

    /**
     *
     */
    public static String[] APP_WARN0077 = {"APP_WARN0077", ""};

    /**
     *
     */
    public static String[] APP_WARN0078 = {"APP_WARN0078", ""};

    /**
     *
     */
    public static String[] APP_WARN0079 = {"APP_WARN0079", ""};

    /**
     *
     */
    public static String[] APP_WARN0080 = {"APP_WARN0080", ""};

    /**
     *
     */
    public static String[] APP_WARN0081 = {"APP_WARN0081", ""};

    /**
     *
     */
    public static String[] APP_WARN0082 = {"APP_WARN0082", ""};

    /**
     *
     */
    public static String[] APP_WARN0083 = {"APP_WARN0083", ""};

    /**
     *
     */
    public static String[] APP_WARN0084 = {"APP_WARN0084", ""};

    /**
     *
     */
    public static String[] APP_WARN0085 = {"APP_WARN0085", ""};

    /**
     *
     */
    public static String[] APP_WARN0086 = {"APP_WARN0086", ""};

    /**
     *
     */
    public static String[] APP_WARN0087 = {"APP_WARN0087", ""};

    /**
     *
     */
    public static String[] APP_WARN0088 = {"APP_WARN0088", ""};

    /**
     *
     */
    public static String[] APP_WARN0089 = {"APP_WARN0089", ""};

    /**
     *
     */
    public static String[] APP_WARN0090 = {"APP_WARN0090", ""};

    /**
     *
     */
    public static String[] APP_WARN0091 = {"APP_WARN0091", ""};

    /**
     *
     */
    public static String[] APP_WARN0092 = {"APP_WARN0092", ""};

    /**
     *
     */
    public static String[] APP_WARN0093 = {"APP_WARN0093", ""};

    /**
     *
     */
    public static String[] APP_WARN0094 = {"APP_WARN0094", ""};

    /**
     *
     */
    public static String[] APP_WARN0095 = {"APP_WARN0095", ""};

    /**
     *
     */
    public static String[] APP_WARN0096 = {"APP_WARN0096", ""};

    /**
     *
     */
    public static String[] APP_WARN0097 = {"APP_WARN0097", ""};

    /**
     *
     */
    public static String[] APP_WARN0098 = {"APP_WARN0098", ""};

    /**
     *
     */
    public static String[] APP_WARN0099 = {"APP_WARN0099", ""};

    /**
     *
     */
    public static String[] APP_WARN0100 = {"APP_WARN0100", ""};

}
